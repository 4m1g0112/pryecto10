var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["4eea9ab5-e5ba-4e58-bae0-e2d12a3ddbc9","bd3431df-b18d-4585-91db-f173748b5026","5e0d43f9-4fe4-4c06-933e-554655405e18","48207f9d-9b43-46a2-89d1-501101215f1c","7b74a3a0-04c6-42b3-9e5e-37d7a66d2076","d6916aa3-8254-4c88-9b03-80801a6b2068"],"propsByKey":{"4eea9ab5-e5ba-4e58-bae0-e2d12a3ddbc9":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/b.wUIlJjGpUDp5hPJOOrJBX9HqHOOATt/category_backgrounds/background_underwater_05.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"b.wUIlJjGpUDp5hPJOOrJBX9HqHOOATt","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/b.wUIlJjGpUDp5hPJOOrJBX9HqHOOATt/category_backgrounds/background_underwater_05.png"},"bd3431df-b18d-4585-91db-f173748b5026":{"name":"hero1","sourceUrl":null,"frameSize":{"x":331,"y":398},"frameCount":1,"looping":true,"frameDelay":12,"version":"0p9sjpHdzCXYoKI3I5Iz7cxR8qufoNNP","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":331,"y":398},"rootRelativePath":"assets/bd3431df-b18d-4585-91db-f173748b5026.png"},"5e0d43f9-4fe4-4c06-933e-554655405e18":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/h5iaduJc2clM0M6koq2mdRkgWrUCcW5Y/category_animals/shark.png","frameSize":{"x":397,"y":185},"frameCount":1,"looping":true,"frameDelay":2,"version":"h5iaduJc2clM0M6koq2mdRkgWrUCcW5Y","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":397,"y":185},"rootRelativePath":"assets/api/v1/animation-library/gamelab/h5iaduJc2clM0M6koq2mdRkgWrUCcW5Y/category_animals/shark.png"},"48207f9d-9b43-46a2-89d1-501101215f1c":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/eUzgrCGnFOCsW37urD4vxPuZLyCsMDGB/category_animals/piranha.png","frameSize":{"x":390,"y":216},"frameCount":1,"looping":true,"frameDelay":2,"version":"eUzgrCGnFOCsW37urD4vxPuZLyCsMDGB","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":216},"rootRelativePath":"assets/api/v1/animation-library/gamelab/eUzgrCGnFOCsW37urD4vxPuZLyCsMDGB/category_animals/piranha.png"},"7b74a3a0-04c6-42b3-9e5e-37d7a66d2076":{"name":"inicio1","sourceUrl":"assets/api/v1/animation-library/gamelab/bAO.iRYZCt9QrUUoYIsB.83ihVH6AQPt/category_aquatic_objects/underseadeco_32.png","frameSize":{"x":397,"y":344},"frameCount":1,"looping":true,"frameDelay":2,"version":"bAO.iRYZCt9QrUUoYIsB.83ihVH6AQPt","categories":["aquatic_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":397,"y":344},"rootRelativePath":"assets/api/v1/animation-library/gamelab/bAO.iRYZCt9QrUUoYIsB.83ihVH6AQPt/category_aquatic_objects/underseadeco_32.png"},"d6916aa3-8254-4c88-9b03-80801a6b2068":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/bBLJm5DhYtD1GEPfECkJg_Pkhaw6.ite/category_animals/urchin.png","frameSize":{"x":374,"y":397},"frameCount":1,"looping":true,"frameDelay":2,"version":"bBLJm5DhYtD1GEPfECkJg_Pkhaw6.ite","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":374,"y":397},"rootRelativePath":"assets/api/v1/animation-library/gamelab/bBLJm5DhYtD1GEPfECkJg_Pkhaw6.ite/category_animals/urchin.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


var hero = createSprite(200,310,200,20);
hero.shapeColor="red";

var  inicio = createSprite(180,372,200,20);
inicio.shapeColor="red";

var enemy1 = createSprite(200,250,10,10);
enemy1.shapeColor="red";

var enemy2 = createSprite(200,150,10,10);
enemy2.shapeColor="red";

var enemy3 = createSprite(200,50,10,10);
enemy3.shapeColor="red";

var net = createSprite(200,18,200,20);
net.shapeColor="red";

var goal =0;
var death = 0;

hero.setAnimation("hero1");
hero.scale=.1;
inicio.setAnimation("inicio1");
inicio.scale=.3;
enemy1.setAnimation("enemy");
enemy1.scale=.3;
enemy2.setAnimation("enemy2");
enemy2.scale=.1;
enemy3.setAnimation("enemy3");
enemy3.scale=.1;
net.setAnimation("hero1");
net.scale=.1;

enemy1.setVelocity(-10,0);
enemy2.setVelocity(10,0);
enemy3.setVelocity(-10,0);


function draw() {
//fondo(b);
background("#2669C1");

createEdgeSprites();




enemy1.bounceOff(edges);
enemy2.bounceOff(edges);
enemy3.bounceOff(edges);
hero.bounceOff(edges);

if(keyDown(UP_ARROW)){
  hero.y=hero.y-3;
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3;
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-3;
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3;
}

if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3");
  hero.x=200;
  hero.y=350;
  death = death+1;
}
if(hero.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3");
  hero.x=200;
  hero.y=345;
  goal=goal+1;
}
textSize(20);
  fill("orange");
  text("Goals:"+goal,320,350);
  

textSize(20);
  fill("black");
  text("death:"+death,20,350);
  
drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
