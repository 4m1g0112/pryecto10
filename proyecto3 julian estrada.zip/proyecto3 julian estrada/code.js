var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var wall1 = createSprite(215, 156, 325, 20);
var wall2 = createSprite(262, 33, 20, 130);
var wall3 = createSprite(336, 140, 20, 350);
var wall4 = createSprite(260, 236, 200,20);
var wall5 = createSprite(160, 40, 200, 20);
var wall6 = createSprite(94, 97, 200, 20);
var wall7 = createSprite(99, 299, 200,20);
var wall8 = createSprite(115, 326,20, 70);
var wall9 = createSprite(206, 350, 179, 20);
var target1 = createSprite(380, 1, 60, 80);
var ball = createSprite(14, 11, 20, 20);

target1.shapeColor = "white";
ball.shapeColor = "#7AE7C7";
function draw() {
  background("pink");
  drawSprites();
  createEdgeSprites();
  ball.bounceOff(edges);

  if(keyDown(UP_ARROW)) {
    ball.velocityX = 0;
    ball.velocityY = -4;
  }
  if (keyDown("DOWN_ARROW")) {
   ball.velocityX = 0;
   ball.velocityY = 4;
  }
  if (keyDown("RIGHT_ARROW")) {
    ball.velocityX = 4;
    ball.velocityY = 0;
  }
  if (keyDown("LEFT_ARROW")) {
    ball.velocityX = -4;
    ball.velocityY = 0;
  }
  if (ball.isTouching(wall1) || ball.isTouching(wall2) || ball.isTouching(wall3)) {
    ball.velocityX = 0;
    ball.velocityY = 0;
    ball.x = 14;
    ball.y = 11;
  }
  if (ball.isTouching(wall4) || ball.isTouching(wall5) || ball.isTouching(wall6)) {
  ball.velocityX = 0;
    ball.velocityY = 0;
    ball.x = 14;
    ball.y = 11;
  }
  if (ball.isTouching(wall7) || ball.isTouching(wall8) || ball.isTouching(wall9)) {
  ball.velocityX = 0;
  ball.velocityY = 0;
    ball.x = 14;
    ball.y = 11;
  } 
  if (ball.isTouching(target1)) {
    textSize(40);
    text("YOU WIN!",124,198);
    textFont("Arial");
    fill("white");
    stroke("white");
    ball.velocityX = 0;
    ball.velocityY = 0;
  }
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
